ENTRY <?php echo $this->menu->menu_id; ?>

<?php 

//if item type is 1 item is entry, display normally
//else if item type is 0 item is description entry, 

        echo $this->menu->item->ALSO ? "ALSOOOO:".$this->menu->item->ALSO : "No Also";
        foreach ($this->menu->item as $property => $value)
        {
            if (is_string($property)) 
                echo "<br><br>" . $property . "--" . $value;
        }
        