<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); 

function PMenuBuildRoute(&$query)
{
	$segments = array();
	return $segments;
}

function PMenuParseRoute($segments) 
{

}